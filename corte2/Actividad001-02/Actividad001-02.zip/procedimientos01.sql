DROP DATABASE IF EXISTS procedimientos01;
CREATE DATABASE procedimientos01 CHARACTER SET utf8mb4;
USE procedimientos01 -A;

CREATE TABLE operaciones (
    numero INT UNSIGNED,
    cuadrado INT UNSIGNED
);

