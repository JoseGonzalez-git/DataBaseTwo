DROP DATABASE IF EXISTS procedimientos;
CREATE DATABASE procedimientos;
USE procedimientos;

CREATE TABLE pares (numero INT UNSIGNED);
CREATE TABLE impares (numero INT UNSIGNED);