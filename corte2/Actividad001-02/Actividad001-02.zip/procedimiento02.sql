DROP DATABASE IF EXISTS procedimientos02;
CREATE DATABASE procedimientos02 CHARACTER SET utf8mb4;
USE procedimientos02 -A;

CREATE TABLE ejercicio (
    numero INT UNSIGNED
);
